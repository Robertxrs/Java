package dio.dio_spring_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DioSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
